﻿using System;

namespace arithmeticProblem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char playAgain = 'y';

            while (playAgain == 'y')
            {
               
                int num1 = random.Next(1, 11); // Generate random number between 1 and 10
                int num2 = random.Next(1, 11); // Generate random number between 1 and 10
                int correctAnswer = num1 + num2;

                Console.WriteLine($"What is {num1} + {num2}?");

                int userAnswer;
                while (!int.TryParse(Console.ReadLine(), out userAnswer))
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                }

                if (userAnswer == correctAnswer)
                {
                    Console.WriteLine("Correct!");
                }
                else
                {
                    Console.WriteLine($"Incorrect. The correct answer is {correctAnswer}.");
                }

                Console.WriteLine("Would you like another question? (y/n)");
                playAgain = Console.ReadKey().KeyChar;
                Console.WriteLine();
            }

        }
    }
}
