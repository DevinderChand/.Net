﻿using DataLayer;
using System.Net.Http.Headers;
using Newtonsoft.Json;

HttpClient client = new()
{
    BaseAddress = new Uri("https://localhost:7297")
};

// Add an Accept header for JSON format.
client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

// List data response.
HttpResponseMessage response = client.GetAsync("weatherforecast/").Result;

if (response.IsSuccessStatusCode)
{
    // Parse the response body.
    string json = response.Content.ReadAsStringAsync().Result;
    Console.WriteLine($"REST API Output: {json}");

    var weatherList = JsonConvert.DeserializeObject<List<WeatherForecast>>(json);
    foreach (var item in weatherList)
    {
        Console.WriteLine(item);
    }
}
else
{
    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
}

// Dispose once all HttpClient calls are complete.
client.Dispose();
