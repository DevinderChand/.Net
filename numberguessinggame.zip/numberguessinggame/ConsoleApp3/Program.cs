﻿namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int secretNumber = random.Next(0, 101);
            bool guessedCorrectly = false;

            Console.WriteLine("Welcome to the Number Guessing Game!");
            Console.WriteLine("Try to guess the secret number between 0 and 100.");

            while (!guessedCorrectly)
            {
                Console.Write("Enter your guess: ");
                int guess;
                while (!int.TryParse(Console.ReadLine(), out guess))
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer between 0 and 100.");
                    Console.Write("Enter your guess: ");
                }

                if (guess < secretNumber)
                {
                    Console.WriteLine("Too low. Try again!");
                }
                else if (guess > secretNumber)
                {
                    Console.WriteLine("Too high. Try again!");
                }
                else
                {
                    guessedCorrectly = true;
                    Console.WriteLine("Congratulations! You guessed the secret number.");
                }
            }

        }
    }
}
