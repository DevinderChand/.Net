﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace A1DevinderChand
{
    public static class DataManager
    {
        public static List<Astronaut> Astronauts = new List<Astronaut>();
        public static List<Mission> Missions = new List<Mission>();

        // Methods for Astronauts

        public static void AddAstronaut(Astronaut astronaut)
        {
            Astronauts.Add(astronaut);
        }

        public static void EditAstronaut(int id, Astronaut updatedAstronaut)
        {
            var astronaut = Astronauts.FirstOrDefault(a => a.Id == id);
            if (astronaut != null)
            {
                astronaut.Name = updatedAstronaut.Name;
                astronaut.Age = updatedAstronaut.Age;
                astronaut.Rank = updatedAstronaut.Rank;
                astronaut.Specialty = updatedAstronaut.Specialty;
            }
        }

        public static void DeleteAstronaut(int id)
        {
            var astronaut = Astronauts.FirstOrDefault(a => a.Id == id);
            if (astronaut != null)
            {
                Astronauts.Remove(astronaut);
            }
        }

        public static List<Astronaut> ViewAstronauts()
        {
            return Astronauts.ToList();
        }

        public static Astronaut SearchAstronaut(int id)
        {
            return Astronauts.FirstOrDefault(a => a.Id == id);
        }

        // Methods for Missions

        public static void AddMission(Mission mission)
        {
            Missions.Add(mission);
        }

        public static void EditMission(int id, Mission updatedMission)
        {
            var mission = Missions.FirstOrDefault(m => m.Id == id);
            if (mission != null)
            {
                mission.Name = updatedMission.Name;
                mission.LaunchDate = updatedMission.LaunchDate;
                mission.Duration = updatedMission.Duration;
                // Update the list of assigned astronauts if needed
                mission.AssignedAstronauts = updatedMission.AssignedAstronauts;
            }
        }

        public static void DeleteMission(int id)
        {
            var mission = Missions.FirstOrDefault(m => m.Id == id);
            if (mission != null)
            {
                Missions.Remove(mission);
            }
        }

        public static List<Mission> ViewMissions()
        {
            return Missions.ToList();
        }

        public static Mission SearchMission(int id)
        {
            return Missions.FirstOrDefault(m => m.Id == id);
        }
    }
    }
