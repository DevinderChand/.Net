﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1DevinderChand
{
    public class Commander : Astronaut
    {
        public Commander(int id, string name, int age, string rank, string specialty)
            : base(id, name, age, rank, specialty) { }

    }
}
