﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1DevinderChand
{
    public abstract class Astronaut
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Rank { get; set; }
        public string Specialty { get; set; }

        public Astronaut(int id, string name, int age, string rank, string specialty)
        {
            Id = id;
            Name = name;
            Age = age;
            Rank = rank;
            Specialty = specialty;
        }
        public override string ToString()
        {
            return $"ID: {Id}, Name: {Name}, Age: {Age}, Rank: {Rank}, Specialty: {Specialty}";
        }
    }
}
