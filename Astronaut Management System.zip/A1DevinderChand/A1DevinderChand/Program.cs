﻿using System.Linq;
using System;

namespace A1DevinderChand
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("Astronaut Management System");
                Console.WriteLine("1. Add Astronaut");
                Console.WriteLine("2. Edit Astronaut");
                Console.WriteLine("3. Delete Astronaut");
                Console.WriteLine("4. View Astronauts");
                Console.WriteLine("5. Search Astronaut");
                Console.WriteLine("6. Add Mission");
                Console.WriteLine("7. Edit Mission");
                Console.WriteLine("8. Delete Mission");
                Console.WriteLine("9. View Missions");
                Console.WriteLine("10. Assign Astronaut to Mission");
                Console.WriteLine("11. Exit");
                Console.Write("Select an option: ");

                int option;
                if (int.TryParse(Console.ReadLine(), out option))
                {
                    switch (option)
                    {
                        case 1:
                            ShowAddAstronautMenu();
                            break;
                        case 2:
                            ShowEditAstronautMenu();
                            break;
                        case 3:
                            ShowDeleteAstronautMenu();
                            break;
                        case 4:
                            ViewAstronauts();
                            break;
                        case 5:
                            SearchAstronaut();
                            break;
                        case 6:
                            AddMission();
                            break;
                        case 7:
                            EditMission();
                            break;
                        case 8:
                            DeleteMission();
                            break;
                        case 9:
                            ViewMissions();
                            break;
                        case 10:
                            AssignAstronautToMission();
                            break;
                        case 11:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Invalid option. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }

                Console.WriteLine();
            }
        }

        static void ShowAddAstronautMenu()
        {
            Console.WriteLine("Select Astronaut Type:");
            Console.WriteLine("1. Add Commander");
            Console.WriteLine("2. Add Pilot");
            Console.WriteLine("3. Add Scientist");
            Console.WriteLine("4. Add Engineer");
            Console.WriteLine("5. Back to Main Menu");
            Console.Write("Select an option: ");

            int option;
            if (int.TryParse(Console.ReadLine(), out option))
            {
                switch (option)
                {
                    case 1:
                        AddAstronaut(new Commander(GetNextAstronautId(), "Commander Name", 45, "Colonel", "Leadership"));
                        break;
                    case 2:
                        AddAstronaut(new Pilot(GetNextAstronautId(), "Pilot Name", 35, "Major", "Navigation"));
                        break;
                    case 3:
                        AddAstronaut(new Scientist(GetNextAstronautId(), "Scientist Name", 40, "Doctor", "Biology"));
                        break;
                    case 4:
                        AddAstronaut(new Engineer(GetNextAstronautId(), "Engineer Name", 30, "Captain", "Mechanical"));
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a number.");
            }
        }

        static void AddAstronaut(Astronaut astronaut)
        {
            DataManager.AddAstronaut(astronaut);
            Console.WriteLine($"{astronaut.GetType().Name} added successfully.");
        }

        static int GetNextAstronautId()
        {
            return DataManager.Astronauts.Any() ? DataManager.Astronauts.Max(a => a.Id) + 1 : 1;
        }

        static void ViewAstronauts()
        {
            var astronauts = DataManager.ViewAstronauts();
            foreach (var astronaut in astronauts)
            {
                Console.WriteLine(astronaut);
            }
        }

        static void SearchAstronaut()
        {
            Console.Write("Enter Astronaut ID: ");
            int id;
            if (int.TryParse(Console.ReadLine(), out id))
            {
                var astronaut = DataManager.SearchAstronaut(id);
                if (astronaut != null)
                {
                    Console.WriteLine(astronaut);
                }
                else
                {
                    Console.WriteLine("Astronaut not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
            }
        }

        static void ShowEditAstronautMenu()
        {
            Console.Write("Enter Astronaut ID to Edit: ");
            int id;
            if (int.TryParse(Console.ReadLine(), out id))
            {
                var astronaut = DataManager.SearchAstronaut(id);
                if (astronaut != null)
                {
                    Console.Write("Enter new Name: ");
                    astronaut.Name = Console.ReadLine();
                    Console.Write("Enter new Age: ");
                    astronaut.Age = int.Parse(Console.ReadLine());
                    Console.Write("Enter new Rank: ");
                    astronaut.Rank = Console.ReadLine();
                    Console.Write("Enter new Specialty: ");
                    astronaut.Specialty = Console.ReadLine();

                    DataManager.EditAstronaut(id, astronaut);
                    Console.WriteLine("Astronaut updated successfully.");
                }
                else
                {
                    Console.WriteLine("Astronaut not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
            }
        }

        static void ShowDeleteAstronautMenu()
        {
            Console.Write("Enter Astronaut ID to Delete: ");
            int id;
            if (int.TryParse(Console.ReadLine(), out id))
            {
                DataManager.DeleteAstronaut(id);
                Console.WriteLine("Astronaut deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
            }
        }

        static void AddMission()
        {
            int id = GetNextMissionId();

            Console.Write("Enter Mission Name: ");
            string name = Console.ReadLine();

            DateTime launchDate;
            while (true)
            {
                Console.Write("Enter Launch Date (yyyy-mm-dd): ");
                if (DateTime.TryParse(Console.ReadLine(), out launchDate))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid date format. Please enter the date in yyyy-mm-dd format.");
                }
            }

            int duration;
            while (true)
            {
                Console.Write("Enter Duration (days): ");
                if (int.TryParse(Console.ReadLine(), out duration) && duration > 0)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid duration. Please enter a positive number.");
                }
            }

            var mission = new Mission(id, name, launchDate, duration);
            MissionManager.AddMission(mission);

            Console.WriteLine("Mission added successfully.");
        }

        static int GetNextMissionId()
        {
            return DataManager.Missions.Any() ? DataManager.Missions.Max(m => m.Id) + 1 : 1;
        }


        static void EditMission()
        {
            Console.Write("Enter Mission ID to Edit: ");
            int id;
            if (int.TryParse(Console.ReadLine(), out id))
            {
                var mission = DataManager.SearchMission(id);
                if (mission != null)
                {
                    Console.Write("Enter new Name: ");
                    mission.Name = Console.ReadLine();
                    Console.Write("Enter new Launch Date (yyyy-mm-dd): ");
                    mission.LaunchDate = DateTime.Parse(Console.ReadLine());
                    Console.Write("Enter new Duration (days): ");
                    mission.Duration = int.Parse(Console.ReadLine());

                    DataManager.EditMission(id, mission);
                    Console.WriteLine("Mission updated successfully.");
                }
                else
                {
                    Console.WriteLine("Mission not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
            }
        }

        static void DeleteMission()
        {
            Console.Write("Enter Mission ID to Delete: ");
            int id;
            if (int.TryParse(Console.ReadLine(), out id))
            {
                DataManager.DeleteMission(id);
                Console.WriteLine("Mission deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
            }
        }

        static void ViewMissions()
        {
            var missions = DataManager.ViewMissions();
            foreach (var mission in missions)
            {
                Console.WriteLine($"ID: {mission.Id}, Name: {mission.Name}, Launch Date: {mission.LaunchDate}, Duration: {mission.Duration} days");
            }
        }

        static void AssignAstronautToMission()
        {
            Console.Write("Enter Mission ID: ");
            int missionId;
            if (int.TryParse(Console.ReadLine(), out missionId))
            {
                var mission = DataManager.SearchMission(missionId);
                if (mission != null)
                {
                    Console.Write("Enter Astronaut ID to Assign: ");
                    int astronautId;
                    if (int.TryParse(Console.ReadLine(), out astronautId))
                    {
                        var astronaut = DataManager.SearchAstronaut(astronautId);
                        if (astronaut != null)
                        {
                            mission.AssignedAstronauts.Add(astronaut);
                            Console.WriteLine($"Astronaut {astronaut.Name} assigned to mission {mission.Name} successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Astronaut not found.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter a valid ID.");
                    }
                }
                else
                {
                    Console.WriteLine("Mission not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid ID.");
            }
        }
     
}
}
