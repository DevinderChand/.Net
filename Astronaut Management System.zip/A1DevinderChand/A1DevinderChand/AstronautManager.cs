﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1DevinderChand
{
    public static class AstronautManager
    {
        public static void AddAstronaut(Astronaut astronaut)
        {
            DataManager.Astronauts.Add(astronaut);
        }

        public static void EditAstronaut(int id, Astronaut updatedAstronaut)
        {
            var astronaut = DataManager.Astronauts.FirstOrDefault(a => a.Id == id);
            if (astronaut != null)
            {
                astronaut.Name = updatedAstronaut.Name;
                astronaut.Age = updatedAstronaut.Age;
                astronaut.Rank = updatedAstronaut.Rank;
                astronaut.Specialty = updatedAstronaut.Specialty;
            }
        }

        public static void DeleteAstronaut(int id)
        {
            var astronaut = DataManager.Astronauts.FirstOrDefault(a => a.Id == id);
            if (astronaut != null)
            {
                DataManager.Astronauts.Remove(astronaut);
            }
        }

        public static List<Astronaut> ViewAstronauts()
        {
            return DataManager.Astronauts;
        }

        public static Astronaut SearchAstronaut(int id)
        {
            return DataManager.Astronauts.FirstOrDefault(a => a.Id == id);
        }
    }

    public static class MissionManager
    {
        public static void AddMission(Mission mission)
        {
            DataManager.Missions.Add(mission);
        }

        public static void EditMission(int id, Mission updatedMission)
        {
            var mission = DataManager.Missions.FirstOrDefault(m => m.Id == id);
            if (mission != null)
            {
                mission.Name = updatedMission.Name;
                mission.LaunchDate = updatedMission.LaunchDate;
                mission.Duration = updatedMission.Duration;
            }
        }

        public static void DeleteMission(int id)
        {
            var mission = DataManager.Missions.FirstOrDefault(m => m.Id == id);
            if (mission != null)
            {
                DataManager.Missions.Remove(mission);
            }
        }

        public static List<Mission> ViewMissions()
        {
            return DataManager.Missions;
        }
    }

}
