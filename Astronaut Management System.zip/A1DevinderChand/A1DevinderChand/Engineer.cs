﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1DevinderChand
{
    public class Engineer : Astronaut
    {
        public Engineer(int id, string name, int age, string rank, string specialty)
            : base(id, name, age, rank, specialty) { }
    }
}
