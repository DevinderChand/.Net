﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1DevinderChand
{
    public class Mission
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime LaunchDate { get; set; }
        public int Duration { get; set; }
        public List<Astronaut> AssignedAstronauts { get; set; }

        public Mission(int id, string name, DateTime launchDate, int duration)
        {
            Id = id;
            Name = name;
            LaunchDate = launchDate;
            Duration = duration;
            AssignedAstronauts = new List<Astronaut>();
        }

        public void AssignAstronaut(Astronaut astronaut)
        {
            AssignedAstronauts.Add(astronaut);
        }
    }

}
