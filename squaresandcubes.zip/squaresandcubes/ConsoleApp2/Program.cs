﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number\tSquare\tCube");
            Console.WriteLine("------\t------\t----");
            for (int i = 0; i <= 10; i++)
            {
                int square = i * i;
                int cube = i * i * i;

                Console.WriteLine($"{i}\t{square}\t{cube}");
            }

        }
    }
}
