﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Console.Write("Enter circle radius: ");
            double r = double.Parse(Console.ReadLine());

            double diameter = 2 * r;
            double circumference = 2 * Math.PI * r;
            double area = Math.PI * r * r;

            Console.WriteLine("Diameter: " + diameter); Console.WriteLine("Circumference: " + circumference); Console.WriteLine("Area: " + area);

        }
    }
}
